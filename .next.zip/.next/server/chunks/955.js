"use strict";
exports.id = 955;
exports.ids = [955];
exports.modules = {

/***/ 3146:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/eng.6c307e22.png","height":614,"width":1024,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFBAMAAACKv7BmAAAAJ1BMVEX09Pbo6u/t5ejc3eTZnKHMjpjjg4LdeXuakKrRWGHWVFlSc6BRc5/bMx8pAAAAHUlEQVR42mMQ3hpjyNDE4qDBkFm1fBqEJbw1xhAAU6sGp2BEOLEAAAAASUVORK5CYII="});

/***/ }),

/***/ 1773:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/ru.cc094501.png","height":1067,"width":1600,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFBAMAAACKv7BmAAAAD1BMVEX////W1+W0OWnbKgAAAKJPYQiNAAAAGUlEQVR42mMAA0EgYHABAgYlIGAwNjY2BgAYAQKptmlK2gAAAABJRU5ErkJggg=="});

/***/ }),

/***/ 3538:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/uz.4f6af0f4.png","height":640,"width":1280,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAEBAMAAABB42PDAAAAJFBMVEXh5Ozf6Nfg4+ze6Nbe4us7nbUAlrEAlLAAjKsAiqoAiqkAqgD/3HGhAAAAHElEQVR42mMIq1g5k4FBxcWFwdhQUJBh9+7duwE3HQYvkkfBLgAAAABJRU5ErkJggg=="});

/***/ })

};
;